year = input ( "When were you born")
#input return always is String
#age = 2019 - int(year)
year = int(year)
age = 2019 - year
print (type(year))
age
print ("Your expected age after 10 years is", age + 10)
