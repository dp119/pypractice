#Sandeep tour of India
#He will travel daily 10 hours and per hour 10kmph speed
#Total travel 10000 kmph

Total_distance = 10000
Total_distance = int(Total_distance)
per_day_working_hours = 10
per_day_working_hours = int(per_day_working_hours)
for_one_hour_speed = 10
for_one_hour_speed = int(for_one_hour_speed)
one_day_distance_travelled = per_day_working_hours * for_one_hour_speed
no_days = int (Total_distance /  one_day_distance_travelled)
print (no_days)

no_days = Total_distance // one_day_distance_travelled
print ("no_days" * 10)

var = "kotesh"
print(var[3])
#print(var[7])
var[3] = '7'
