runs = [70, 110, 30, 90, 40]
runs.sort()
print(runs)

