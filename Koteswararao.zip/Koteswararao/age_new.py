

def find_age(year_of_birth, present_year) :
    print ( "users age", present_year - year_of_birth)

def main():
    year_of_birth = int(input("Print thr year born"))
    find_age(year_of_birth, 2019)

main()    


