name = input("Enter your name:")
print("hello "+ name+ " !!!")
print("hello", name, "!!!")

(a,b,c) = 10, "abc", (20 / 5)
print (a,b,c)

