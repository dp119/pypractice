import math
print (math.pi)
